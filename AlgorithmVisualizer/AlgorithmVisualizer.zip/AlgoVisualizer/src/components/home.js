import React from 'react';

const Home = () => {
  return (
    <section id="home">
      <h1>Welcome to Sorting Algorithms Visualiser</h1>
      <p>Explore various sorting algorithms and their implementations along with Visualisation.</p>
    </section>
  );
};

export default Home;