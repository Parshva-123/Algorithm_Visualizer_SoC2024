// src/components/QuickSortingAlgorithms.js
export const quickSort = (array) => {
    const animations = [];
    quickSortHelper(array, 0, array.length - 1, animations);
    return animations;
  };
  
  const quickSortHelper = (array, left, right, animations) => {
    if (left < right) {
      const pivotIndex = partition(array, left, right, animations);
      quickSortHelper(array, left, pivotIndex - 1, animations);
      quickSortHelper(array, pivotIndex + 1, right, animations);
    }
  };
  
  const partition = (array, left, right, animations) => {
    const pivot = array[right];
    let i = left - 1;
    for (let j = left; j <= right - 1; j++) {
      animations.push([j, right]);
      animations.push([j, right]);
      if (array[j] < pivot) {
        i++;
        animations.push([i, j]);
        animations.push([i, j]);
        [array[i], array[j]] = [array[j], array[i]];
      }
    }
    animations.push([i + 1, right]);
    animations.push([i + 1, right]);
    [array[i + 1], array[right]] = [array[right], array[i + 1]];
    return i + 1;
  };