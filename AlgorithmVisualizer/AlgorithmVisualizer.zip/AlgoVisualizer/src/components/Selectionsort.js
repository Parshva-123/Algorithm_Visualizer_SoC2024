// src/components/SelectionSortingAlgorithms.js
export const selectionSort = (array) => {
    const animations = [];
    for (let i = 0; i < array.length - 1; i++) {
      let minIdx = i;
      for (let j = i + 1; j < array.length; j++) {
        animations.push([j, minIdx]);
        animations.push([j, minIdx]);
        if (array[j] < array[minIdx]) {
          minIdx = j;
        }
      }
      animations.push([i, minIdx]);
      animations.push([i, minIdx]);
      [array[i], array[minIdx]] = [array[minIdx], array[i]];
    }
    return animations;
  };