import React from 'react';
import { Link } from 'react-router-dom';

const Navigation = () => {
  return (
    <nav>
      <label className="logo">SortMaster</label>
      <input type="checkbox" id="check" />
      <label htmlFor="check" className="checkbtn">
        <i className="fas fa-bars"></i>
      </label>
      <ul>
        <li><Link to="/" className="active">Home</Link></li>
        <li><Link to="/selection">Selection Sort</Link></li>
        <li><Link to="/insertion">Insertion Sort</Link></li>
        <li><Link to="/bubble">Bubble Sort</Link></li>
        <li><Link to="/merge">Merge Sort</Link></li>
        <li><Link to="/quick">Quick Sort</Link></li>
      </ul>
    </nav>
  );
};

export default Navigation;