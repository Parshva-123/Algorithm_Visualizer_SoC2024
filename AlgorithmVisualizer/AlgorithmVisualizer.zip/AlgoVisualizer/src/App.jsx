import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navigation from './components/navigation'
import Home from './components/home';
import SelectionSort from './components/SelectionSort';
import InsertionSort from './components/InsertionSort';
import BubbleSort from './components/BubbleSort';
import MergeSort from './components/MergeSort';
import QuickSort from './components/QuickSort';
import './AlgoVis.css';

const App = () => {
  return (
    <Router>
      <Navigation />
      <div className="content">
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/selection" component={SelectionSort} />
          <Route path="/insertion" component={InsertionSort} />
          <Route path="/bubble" component={BubbleSort} />
          <Route path="/merge" component={MergeSort} />
          <Route path="/quick" component={QuickSort} />
        </Switch>
      </div>
    </Router>
  );
};

export default App;